package annotation;

public enum CacheType {
    IN_MEMORY, FILE
}
