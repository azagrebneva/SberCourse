package threadpool;

public class FixedThreadPool extends GeneralThreadPool {

    public FixedThreadPool(int size) {
        super(size);
    }
}
