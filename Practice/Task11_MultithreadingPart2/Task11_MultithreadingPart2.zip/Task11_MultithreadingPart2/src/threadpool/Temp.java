package threadpool;

public class Temp {


//    public void execute(Runnable command) {
//        if (command == null)
//            throw new NullPointerException();
//        /*
//         * Proceed in 3 steps:
//         *
//         * 1. If fewer than corePoolSize threads are running, try to
//         * start a new thread with the given command as its first
//         * task.  The call to addWorker atomically checks runState and
//         * workerCount, and so prevents false alarms that would add
//         * threads when it shouldn't, by returning false.
//         *
//         * 2. If a task can be successfully queued, then we still need
//         * to double-check whether we should have added a thread
//         * (because existing ones died since last checking) or that
//         * the pool shut down since entry into this method. So we
//         * recheck state and if necessary roll back the enqueuing if
//         * stopped, or start a new thread if there are none.
//         *
//         * 3. If we cannot queue task, then we try to add a new
//         * thread.  If it fails, we know we are shut down or saturated
//         * and so reject the task.
//         */
//        int c = ctl.get();
//        if (workerCountOf(c) < corePoolSize) {
//            if (addWorker(command, true))
//                return;
//            c = ctl.get();
//        }
//        if (isRunning(c) && workQueue.offer(command)) {
//            int recheck = ctl.get();
//            if (! isRunning(recheck) && remove(command))
//                reject(command);
//            else if (workerCountOf(recheck) == 0)
//                addWorker(null, false);
//        }
//        else if (!addWorker(command, false))
//            reject(command);
//    }


    // внутренний класс Worker
//    private final class Worker
//            extends AbstractQueuedSynchronizer
//            implements Runnable

//    2. Создание потока
//    private static class DefaultThreadFactory implements ThreadFactory {
//        private static final AtomicInteger poolNumber = new AtomicInteger(1);
//        private final ThreadGroup group;
//        private final AtomicInteger threadNumber = new AtomicInteger(1);
//        private final String namePrefix;
//
//        DefaultThreadFactory() {
//            SecurityManager s = System.getSecurityManager();
//            group = (s != null) ? s.getThreadGroup() :
//                    Thread.currentThread().getThreadGroup();
//            namePrefix = "pool-" +
//                    poolNumber.getAndIncrement() +
//                    "-thread-";
//        }
//
//        public Thread newThread(Runnable r) {
//            Thread t = new Thread(group, r,
//                    namePrefix + threadNumber.getAndIncrement(),
//                    0);
//            if (t.isDaemon())
//                t.setDaemon(false);
//            if (t.getPriority() != Thread.NORM_PRIORITY)
//                t.setPriority(Thread.NORM_PRIORITY);
//            return t;
//        }
//    }

//    //3. Работа потока ThreadPoolExecutor
//    final void runWorker(ThreadPoolExecutor.Worker w) {
//        Thread wt = Thread.currentThread();
//        Runnable task = w.firstTask;
//        w.firstTask = null;
//        w.unlock(); // allow interrupts
//        boolean completedAbruptly = true;
//        try {
//            while (task != null || (task = getTask()) != null) {
//                w.lock();
//                // If pool is stopping, ensure thread is interrupted;
//                // if not, ensure thread is not interrupted.  This
//                // requires a recheck in second case to deal with
//                // shutdownNow race while clearing interrupt
//                if ((runStateAtLeast(ctl.get(), STOP) ||
//                        (Thread.interrupted() &&
//                                runStateAtLeast(ctl.get(), STOP))) &&
//                        !wt.isInterrupted())
//                    wt.interrupt();
//                try {
//                    beforeExecute(wt, task);
//                    try {
//                        task.run();
//                        afterExecute(task, null);
//                    } catch (Throwable ex) {
//                        afterExecute(task, ex);
//                        throw ex;
//                    }
//                } finally {
//                    task = null;
//                    w.completedTasks++;
//                    w.unlock();
//                }
//            }
//            completedAbruptly = false;
//        } finally {
//            processWorkerExit(w, completedAbruptly);
//        }
//    }

//    4. Получить задание
//    /**
//     * Performs blocking or timed wait for a task, depending on
//     * current configuration settings, or returns null if this worker
//     * must exit because of any of:
//     * 1. There are more than maximumPoolSize workers (due to
//     *    a call to setMaximumPoolSize).
//     * 2. The pool is stopped.
//     * 3. The pool is shutdown and the queue is empty.
//     * 4. This worker timed out waiting for a task, and timed-out
//     *    workers are subject to termination (that is,
//     *    {@code allowCoreThreadTimeOut || workerCount > corePoolSize})
//     *    both before and after the timed wait, and if the queue is
//     *    non-empty, this worker is not the last thread in the pool.
//     *
//     * @return task, or null if the worker must exit, in which case
//     *         workerCount is decremented
//     */
//    private Runnable getTask() {
//        boolean timedOut = false; // Did the last poll() time out?
//
//        for (;;) {
//            int c = ctl.get();
//
//            // Check if queue empty only if necessary.
//            if (runStateAtLeast(c, SHUTDOWN)
//                    && (runStateAtLeast(c, STOP) || workQueue.isEmpty())) {
//                decrementWorkerCount();
//                return null;
//            }
//
//            int wc = workerCountOf(c);
//
//            // Are workers subject to culling?
//            boolean timed = allowCoreThreadTimeOut || wc > corePoolSize;
//
//            if ((wc > maximumPoolSize || (timed && timedOut))
//                    && (wc > 1 || workQueue.isEmpty())) {
//                if (compareAndDecrementWorkerCount(c))
//                    return null;
//                continue;
//            }
//
//            try {
//                Runnable r = timed ?
//                        workQueue.poll(keepAliveTime, TimeUnit.NANOSECONDS) :
//                        workQueue.take();
//                if (r != null)
//                    return r;
//                timedOut = true;
//            } catch (InterruptedException retry) {
//                timedOut = false;
//            }
//        }
//    }


//    private void interruptIdleWorkers(boolean onlyOne) {
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            for (ThreadPoolExecutor.Worker w : workers) {
//                Thread t = w.thread;
//                if (!t.isInterrupted() && w.tryLock()) {
//                    try {
//                        t.interrupt();
//                    } catch (SecurityException ignore) {
//                    } finally {
//                        w.unlock();
//                    }
//                }
//                if (onlyOne)
//                    break;
//            }
//        } finally {
//            mainLock.unlock();
//        }
//    }

//    /**
//     * Initiates an orderly shutdown in which previously submitted
//     * tasks are executed, but no new tasks will be accepted.
//     * Invocation has no additional effect if already shut down.
//     *
//     * <p>This method does not wait for previously submitted tasks to
//     * complete execution.  Use {@link #awaitTermination awaitTermination}
//     * to do that.
//     *
//     * @throws SecurityException {@inheritDoc}
//     */
//    public void shutdown() {
//        final ReentrantLock mainLock = this.mainLock;
//        mainLock.lock();
//        try {
//            checkShutdownAccess();
//            advanceRunState(SHUTDOWN);
//            interruptIdleWorkers();
//            onShutdown(); // hook for ScheduledThreadPoolExecutor
//        } finally {
//            mainLock.unlock();
//        }
//        tryTerminate();
//    }

}

//
//public class ThreadPoolMain {
//
//    public static void main(String[] args) {
//
//
//
////        // Executors.newFixedThreadPool(5);
//        ExecutorService executor = Executors.newFixedThreadPool(2);
////
////        // Cast the object to its class type
////        ThreadPoolExecutor pool = (ThreadPoolExecutor) executor;
////
////        // Stats before tasks execution
////        System.out.println("Largest executions: "
////                + pool.getLargestPoolSize());
////        System.out.println("Maximum allowed threads: "
////                + pool.getMaximumPoolSize());
////        System.out.println("Current threads in pool: "
////                + pool.getPoolSize());
////        System.out.println("Currently executing threads: "
////                + pool.getActiveCount());
////        System.out.println("Total number of threads(ever scheduled): "
////                + pool.getTaskCount());
////
//        executor.execute(new Task());
//        executor.submit(new Task());
//        executor.submit(new Task());
////
////        // Stats after tasks execution
////        System.out.println("Core threads: " + pool.getCorePoolSize());
////        System.out.println("Largest executions: "
////                + pool.getLargestPoolSize());
////        System.out.println("Maximum allowed threads: "
////                + pool.getMaximumPoolSize());
////        System.out.println("Current threads in pool: "
////                + pool.getPoolSize());
////        System.out.println("Currently executing threads: "
////                + pool.getActiveCount());
////        System.out.println("Total number of threads(ever scheduled): "
////                + pool.getTaskCount());
////
////        executor.shutdown();
//    }
//
//    static class Task implements Runnable {
//        @Override
//        public void run() {
//            try {
//                Long duration = (long) (Math.random() * 5);
//                System.out.println("Running Task! Thread Name: " +
//                        Thread.currentThread().getName());
//                TimeUnit.SECONDS.sleep(duration);
//                System.out.println("Task Completed! Thread Name: " +
//                        Thread.currentThread().getName());
//            } catch (InterruptedException e) {
//                e.printStackTrace();
//            }
//        }
//    }
//
//}
