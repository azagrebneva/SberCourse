import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ClientHandler implements Runnable {

    private Socket socket;
    private PrintWriter out;
    private Scanner in;
    private String clientName;
    private static int clientsCount = 0;

    public ClientHandler(Socket s) {
        this.socket = s;
        try {
            out = new PrintWriter(s.getOutputStream());
            in = new Scanner(s.getInputStream());
            clientsCount++;
            clientName = "Client #" + clientsCount;
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void run() {
        while(true) {
            if (in.hasNext()){
                String message = in.nextLine();
                System.out.println(clientName + ": "+ message);
                out.println("ECHO: "+ message);
                out.flush();

                if (message.equalsIgnoreCase("END")) break;
            }
        }
        try{
            System.out.println("Client disconnected");
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
