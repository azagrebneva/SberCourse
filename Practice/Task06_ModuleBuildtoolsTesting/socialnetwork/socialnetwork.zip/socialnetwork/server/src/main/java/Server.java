import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    private final int serverPort;
    private ServerSocket server;

    public Server(int port) {
        this.serverPort = port;
        Socket socket = null;

        try {
            server = new ServerSocket(serverPort);
            System.out.println("Echo Server created. Waiting for a client ... ");
            while(true){
                socket = server.accept();
                System.out.println("Client connected");
                Runnable threadData = new ClientHandler(socket);
                new Thread(threadData).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if (server != null) server.close();
                System.out.println("Server closed.");
                if (socket != null) socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }


}
