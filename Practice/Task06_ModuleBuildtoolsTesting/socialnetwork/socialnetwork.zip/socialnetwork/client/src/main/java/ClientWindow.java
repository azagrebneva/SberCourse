import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ClientWindow extends JFrame {

    private JTextField clientMsgElement;
    private JTextArea serverMsgElement;

    final String serverHost;
    final int serverPort;

    Socket socket;
    Scanner in;
    PrintWriter out;

    public ClientWindow(String host, int port) {
        this.serverHost = host;
        this.serverPort = port;

        initConnection();
        initGUI();
        initServerListner();
    }

    private void initConnection() {
        try {
            socket = new Socket(serverHost, serverPort);
            in = new Scanner(socket.getInputStream());
            out = new PrintWriter(socket.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void initGUI(){
        setBounds(600, 300, 500, 500);
        setTitle("Echo client");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        serverMsgElement = new JTextArea();
        serverMsgElement.setEditable(false);
        serverMsgElement.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(serverMsgElement);
        add(scrollPane, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel(new BorderLayout());
        add(bottomPanel, BorderLayout.SOUTH);

        JButton sendButton = new JButton("SEND");
        bottomPanel.add(sendButton, BorderLayout.EAST);
        clientMsgElement = new JTextField();
        bottomPanel.add(clientMsgElement,BorderLayout.CENTER);

        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = clientMsgElement.getText();
                sendMessage(message);
            }
        });

        clientMsgElement.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String message = clientMsgElement.getText();
                sendMessage(message);
            }
        });

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                super.windowClosing(e);
                closeConnections();
            }
        });

        setVisible(true);
    }

    private void closeConnections(){
        try {
            if (out != null) {
                out.println("END");
                out.flush();
                out.close();
            }
            if (socket != null) socket.close();
            if (in != null) in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendMessage(String message){
        if (!message.trim().isEmpty()){
            out.println(message);
            out.flush();
            clientMsgElement.setText("");
        }
    }

    private void initServerListner(){
        new Thread(new Runnable() {
            @Override
            public void run() {
                try{
                    while (true) {
                        if (in.hasNext()) {
                            String message = in.nextLine();
                            if (message.equalsIgnoreCase("ECHO: end")) {
                                System.out.println("I am here");
                                break;
                            }
                            serverMsgElement.append(message + "\n");
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }).start();
    }
}
