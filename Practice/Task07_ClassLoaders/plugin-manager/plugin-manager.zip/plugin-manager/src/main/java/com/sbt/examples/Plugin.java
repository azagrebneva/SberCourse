package com.sbt.examples;

public interface Plugin {

    // methods doesn't matter
    void doUsefull();
}

