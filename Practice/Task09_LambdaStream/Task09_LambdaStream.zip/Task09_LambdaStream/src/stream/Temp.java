package stream;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.*;
public class Temp {


    public static <T> Streams<T> of(List list) {
        //return StreamSupport.stream(spliterator(array, startInclusive, endExclusive), false);
        return (Streams<T>) StreamSupport.stream(list.spliterator(), false);
    }
//        1. @SafeVarargs
//        @SuppressWarnings("varargs") // Creating a stream from an array is safe
//        public static<T> Stream<T> of(T... values) {
//            return Arrays.stream(values);
//        }
//        2. public static <T> Stream<T> stream(T[] array) {
//            return stream(array, 0, array.length);
//        }
//        3. public static <T> Stream<T> stream(T[] array, int startInclusive, int endExclusive) {
//            return StreamSupport.stream(spliterator(array, startInclusive, endExclusive), false);
//        }
//        4. public static <T> Stream<T> stream(Spliterator<T> spliterator, boolean parallel) {
//            Objects.requireNonNull(spliterator);
//            return new ReferencePipeline.Head<>(spliterator,
//                    StreamOpFlag.fromCharacteristics(spliterator),
//                    parallel);
//        }
//        5. Head(Spliterator<?> source,
//        int sourceFlags, boolean parallel) {
//            super(source, sourceFlags, parallel);
//        }
//        6. ReferencePipeline(Spliterator<?> source,
//        int sourceFlags, boolean parallel) {
//            super(source, sourceFlags, parallel);
//        }
//        7. Constructor for the head of a stream pipeline.
//        Params:
//        source – Spliterator describing the stream source
//        sourceFlags – the source flags for the stream source, described in StreamOpFlag
//        parallel – true if the pipeline is parallel
//        AbstractPipeline(Spliterator<?> source,
//        int sourceFlags, boolean parallel) {
//            this.previousStage = null;
//            this.sourceSpliterator = source;
//            this.sourceStage = this;
//            this.sourceOrOpFlags = sourceFlags & StreamOpFlag.STREAM_MASK;
//            // The following is an optimization of:
//            // StreamOpFlag.combineOpFlags(sourceOrOpFlags, StreamOpFlag.INITIAL_OPS_VALUE);
//            this.combinedFlags = (~(sourceOrOpFlags << 1)) & StreamOpFlag.INITIAL_OPS_VALUE;
//            this.depth = 0;
//            this.parallel = parallel;
//        }

    public<T> Streams<T> filter(Predicate<? super T> predicate) {return null;}
//    1. @Override
//    public final Stream<P_OUT> filter(Predicate<? super P_OUT> predicate) {
//        Objects.requireNonNull(predicate);
//        return new ReferencePipeline.StatelessOp<P_OUT, P_OUT>(this, StreamShape.REFERENCE,
//                StreamOpFlag.NOT_SIZED) {
//            @Override
//            Sink<P_OUT> opWrapSink(int flags, Sink<P_OUT> sink) {
//                return new Sink.ChainedReference<P_OUT, P_OUT>(sink) {
//                    @Override
//                    public void begin(long size) {
//                        downstream.begin(-1);
//                    }
//
//                    @Override
//                    public void accept(P_OUT u) {
//                        if (predicate.test(u))
//                            downstream.accept(u);
//                    }
//                };
//            }
//        };
//    }
//    в ReferencePipeline abstract static class StatelessOp<E_IN, E_OUT> extends ReferencePipeline<E_IN, E_OUT> {
//    /**
//     * Construct a new Stream by appending a stateless intermediate
//     * operation to an existing stream.
//     *
//     * @param upstream The upstream pipeline stage
//     * @param inputShape The stream shape for the upstream pipeline stage
//     * @param opFlags Operation flags for the new stage
//     */
//    2. StatelessOp(AbstractPipeline<?, E_IN, ?> upstream,
//                StreamShape inputShape,
//                int opFlags) {
//        super(upstream, opFlags);
//        assert upstream.getOutputShape() == inputShape;
//    }
//    3. ReferencePipeline(AbstractPipeline<?, P_IN, ?> upstream, int opFlags) {
//       super(upstream, opFlags);
//    }
//    4. AbstractPipeline(AbstractPipeline<?, E_IN, ?> previousStage, int opFlags) {
//    if (previousStage.linkedOrConsumed)
//        throw new IllegalStateException(MSG_STREAM_LINKED);
//    previousStage.linkedOrConsumed = true;
//    previousStage.nextStage = this;
//
//    this.previousStage = previousStage;
//    this.sourceOrOpFlags = opFlags & StreamOpFlag.OP_MASK;
//    this.combinedFlags = StreamOpFlag.combineOpFlags(opFlags, previousStage.combinedFlags);
//    this.sourceStage = previousStage.sourceStage;
//    if (opIsStateful())
//        sourceStage.sourceAnyStateful = true;
//    this.depth = previousStage.depth + 1;
//}

    public <T, K,U> Map<K,U> toMap(Function<? super T, ? extends K> keyMapper,
                                Function<? super T, ? extends U> valueMapper) {
        return null;
    }
//    @Override
//    @SuppressWarnings("unchecked")
//    1. public final <R, A> R collect(Collector<? super P_OUT, A, R> collector) {
//        A container;
//        if (isParallel()
//                && (collector.characteristics().contains(Collector.Characteristics.CONCURRENT))
//                && (!isOrdered() || collector.characteristics().contains(Collector.Characteristics.UNORDERED))) {
//            container = collector.supplier().get();
//            BiConsumer<A, ? super P_OUT> accumulator = collector.accumulator();
//            forEach(u -> accumulator.accept(container, u));
//        }
//        else {
//            container = evaluate(ReduceOps.makeRef(collector));
//        }
//        return collector.characteristics().contains(Collector.Characteristics.IDENTITY_FINISH)
//                ? (R) container
//                : collector.finisher().apply(container);
//    }
//    2. /**
//     * Evaluate the pipeline with a terminal operation to produce a result.
//     *
//     * @param <R> the type of result
//     * @param terminalOp the terminal operation to be applied to the pipeline.
//     * @return the result
//     */
//    final <R> R evaluate(TerminalOp<E_OUT, R> terminalOp) {
//        assert getOutputShape() == terminalOp.inputShape();
//        if (linkedOrConsumed)
//            throw new IllegalStateException(MSG_STREAM_LINKED);
//        linkedOrConsumed = true;
//
//        return isParallel()
//                ? terminalOp.evaluateParallel(this, sourceSpliterator(terminalOp.getOpFlags()))
//                : terminalOp.evaluateSequential(this, sourceSpliterator(terminalOp.getOpFlags()));
//    }
//    3.ReduceOp
//    @Override
//    public <P_IN> R evaluateSequential(PipelineHelper<T> helper,
//                                   Spliterator<P_IN> spliterator) {
//    return helper.wrapAndCopyInto(makeSink(), spliterator).get();
//    }
//    4. AbstractPipeline
//    @Override
//    final <P_IN, S extends Sink<E_OUT>> S wrapAndCopyInto(S sink, Spliterator<P_IN> spliterator) {
//        copyInto(wrapSink(Objects.requireNonNull(sink)), spliterator);
//        return sink;
//    }
//    5. @Override
//    final <P_IN> void copyInto(Sink<P_IN> wrappedSink, Spliterator<P_IN> spliterator) {
//        Objects.requireNonNull(wrappedSink);
//
//        if (!StreamOpFlag.SHORT_CIRCUIT.isKnown(getStreamAndOpFlags())) {
//            wrappedSink.begin(spliterator.getExactSizeIfKnown());
//            spliterator.forEachRemaining(wrappedSink);
//            wrappedSink.end();
//        }
//        else {
//            copyIntoWithCancel(wrappedSink, spliterator);
//        }
//    }
//6. @Override
//@SuppressWarnings("unchecked")
//final <P_IN> boolean copyIntoWithCancel(Sink<P_IN> wrappedSink, Spliterator<P_IN> spliterator) {
//    @SuppressWarnings({"rawtypes","unchecked"})
//    AbstractPipeline p = AbstractPipeline.this;
//    while (p.depth > 0) {
//        p = p.previousStage;
//    }
//
//    wrappedSink.begin(spliterator.getExactSizeIfKnown());
//    boolean cancelled = p.forEachWithCancel(spliterator, wrappedSink);
//    wrappedSink.end();
//    return cancelled;
//}
//@Override
//@SuppressWarnings("unchecked")
//final <P_IN> Sink<P_IN> wrapSink(Sink<E_OUT> sink) {
//    Objects.requireNonNull(sink);
//
//    for ( @SuppressWarnings("rawtypes") AbstractPipeline p=AbstractPipeline.this; p.depth > 0; p=p.previousStage) {
//        sink = p.opWrapSink(p.previousStage.combinedFlags, sink);
//    }
//    return (Sink<P_IN>) sink;
//}


//    Просто пример программного кода
//public static <T, R> TerminalOp<T, R>
//makeRef(Supplier<R> seedFactory,
//        BiConsumer<R, ? super T> accumulator,
//        BiConsumer<R,R> reducer) {
//    Objects.requireNonNull(seedFactory);
//    Objects.requireNonNull(accumulator);
//    Objects.requireNonNull(reducer);
//    class ReducingSink extends ReduceOps.Box<R>
//            implements ReduceOps.AccumulatingSink<T, R, ReducingSink> {
//        @Override
//        public void begin(long size) {
//            state = seedFactory.get();
//        }
//
//        @Override
//        public void accept(T t) {
//            accumulator.accept(state, t);
//        }
//
//        @Override
//        public void combine(ReducingSink other) {
//            reducer.accept(state, other.state);
//        }
//    }
//    return new ReduceOps.ReduceOp<T, R, ReducingSink>(StreamShape.REFERENCE) {
//        @Override
//        public ReducingSink makeSink() {
//            return new ReducingSink();
//        }
//    };
//}
//    private static <T, K, V>
//    BiConsumer<Map<K, V>, T> uniqKeysMapAccumulator(Function<? super T, ? extends K> keyMapper,
//                                                    Function<? super T, ? extends V> valueMapper) {
//        return (map, element) -> {
//            K k = keyMapper.apply(element);
//            V v = Objects.requireNonNull(valueMapper.apply(element));
//            V u = map.putIfAbsent(k, v);
//            if (u != null) throw duplicateKeyException(k, u, v);
//        };
//    }

    public <R,T> Streams<R> transform(Function<? super T, ? extends R> mapper) {
        return null;
    }
    //public final <R> Stream<R> map(Function<? super P_OUT, ? extends R> mapper) {
//  1. @Override
//    @SuppressWarnings("unchecked")
//    public final <R> Stream<R> map(Function<? super P_OUT, ? extends R> mapper) {
//        Objects.requireNonNull(mapper);
//        return new ReferencePipeline.StatelessOp<P_OUT, R>(this, StreamShape.REFERENCE,
//                StreamOpFlag.NOT_SORTED | StreamOpFlag.NOT_DISTINCT) {
//            @Override
//            Sink<P_OUT> opWrapSink(int flags, Sink<R> sink) {
//                return new Sink.ChainedReference<P_OUT, R>(sink) {
//                    @Override
//                    public void accept(P_OUT u) {
//                        downstream.accept(mapper.apply(u));
//                    }
//                };
//            }
//        };
//    }


    public static void main(String[] args) {
    }
        //        Stream.of("one", "two", "three", "four")
//                .filter(e -> e.length() > 3)
//                .peek(e -> System.out.println("Filtered value: " + e))
//                .map(String::toUpperCase)
//                .peek(e -> System.out.println("Mapped value: " + e))
//                .collect(Collectors.toList());
//
//        List<String> words = Arrays.asList("Oracle", "Java", "Magazine");
//        List<Integer> wordLengths =
//                words.stream()
//                        .map(String::length)
//                        .collect(toList());
//
//        Stream<String> s = Stream.of("apple", "banana", "orange");
//        Map<Character, String> m = s.collect(
//                Collectors.toMap(s1 -> s1.charAt(0),
//                        s1 -> s1));
//        System.out.println(m);
}
